MADARASATU HAYATUL ISLAM - SHARHUL QAWA'IDUL ARBA'A

Wannan Android Studio project ne da aka shirya daga PDF mai shafuka 22.
Manhajar tana dauke da shafukan littafin a matsayin hotuna, saboda haka tana aiki ba tare da Internet ba.

YADDA ZA A GINA APK:
1. A girka Android Studio a kwamfuta.
2. A bude Android Studio, a zabi Open, sannan a zabi wannan babban folder din.
3. A jira Gradle Sync ya kammala. Idan ya tambayi Android SDK 35, a girka shi daga SDK Manager.
4. A menu, a zabi Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Bayan an gama, a danna locate domin samun app-debug.apk.
6. A tura APK din zuwa wayar Android, a bude shi, sannan a amince da Install unknown apps idan wayar ta tambaya.

Bayanin fasaha: applicationId = com.madarasatu.hayatulislam; min Android = 6.0 (API 23).
Wannan ZIP din project ne, ba APK da aka riga aka compile ba.
